﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace IndividualAssignment4
{
	[Activity(Label = "Tansaction")]

	public class Transaction: Activity
    {

		String[] Name = {"KwikTrip", "Walmart", "KMart", "Walgreens", "Applebees", "Ponderosa", "BP", "Dairy Queen", "McDonalds", "BK", "Reeve", "Jack's", "Best Buy", "Target", "JackNBox", "BenJerry", "NorthShore", "Bar", "Varsity", "TrailsEnd", "Avenue", "GBGames", "Blockbuster"};
		String[] Date = { "1/1/18", "1/2/18", "1/3/18", "11/4/18", "11/5/18", "11/6/18", "11/7/18", "11/8/18", "11/9/18", "11/10/18", "11/11/18", "11/12/18", "11/13/18", "11/14/18", "11/15/18", "11/16/18", "11/17/18", "11/18/18", "11/19/18", "11/20/18", "11/21/18", "11/22/18", "11/23/18", };
		String[] Amount = { "$1", "$2", "$3", "$4", "$5", "$6", "$7", "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$16", "$17", "$18", "$19", "$20", "$21", "$22", "$23"};
		ListView lstItem;
		TextView txtview1;
		String getitdone;

		protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.TransactionPage);

			lstItem = FindViewById<ListView>(Resource.Id.lstItem);
			txtview1 = FindViewById<TextView>(Resource.Id.textView1);

			Random randomNumber = new Random();
			double transactionCost = randomNumber.Next(0, 24);
			getitdone = Name[1]; 

			txtview1.SetText(getitdone);
		}


    }
}