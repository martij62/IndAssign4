﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace IndividualAssignment4
{
    [Activity(Label = "Account")]

    public class Account : Activity
    {

        Button btnChecking;
        Button btnSavings;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.AccountsPage);

            btnChecking = FindViewById<Button>(Resource.Id.btnChecking);
            btnSavings = FindViewById<Button>(Resource.Id.btnSavings);

            btnChecking.Click += BtnChecking_Click;
            btnSavings.Click += BtnSavings_Click;
        }

        private void BtnSavings_Click(object sender, EventArgs e)
        {
            StartActivity(typeof(Transaction));
        }

        private void BtnChecking_Click(object sender, EventArgs e)
        {
            StartActivity(typeof(Transaction));
        }
    }
}